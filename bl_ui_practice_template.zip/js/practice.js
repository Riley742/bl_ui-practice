document.getElementById('startBtn').addEventListener('click', () => {
  const displayTime = parseInt(document.getElementById('displayTime').value, 10) * 1000;
  const seqLen = parseInt(document.getElementById('seqLen').value, 10);

  const gameArea = document.getElementById('gameArea');
  const feedback = document.getElementById('feedback');
  feedback.textContent = '';

  const seq = Array.from({length: seqLen}, () => Math.floor(Math.random()*9)+1);
  gameArea.textContent = 'Memorize: ' + seq.join(' ');

  setTimeout(() => {
    gameArea.textContent = 'Now enter the sequence: ';
    const input = document.createElement('input');
    input.type = 'text';
    gameArea.appendChild(input);
    input.focus();

    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        const val = input.value.trim().split('').map(Number);
        if (JSON.stringify(val) === JSON.stringify(seq)) {
          feedback.textContent = '✅ Success!';
        } else {
          feedback.textContent = '❌ Fail! Correct was: ' + seq.join('');
        }
        gameArea.removeChild(input);
      }
    });
  }, displayTime);
});
