# bl_ui Practice Mode

This is a starter template for a static website to practise UI concepts inspired by **bl_ui**.

## How to use
1. Edit the files to customize your practice game.
2. Push the folder to a GitHub repository.
3. Enable GitHub Pages in **Settings → Pages**.
4. Visit the published URL to practice.

## Next steps
- Add more minigames
- Add leaderboard using localStorage
